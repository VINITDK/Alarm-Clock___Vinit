# Alarmclock

This app will let you set and manage alarms and see current time !
This is a part of my frontend skills test
